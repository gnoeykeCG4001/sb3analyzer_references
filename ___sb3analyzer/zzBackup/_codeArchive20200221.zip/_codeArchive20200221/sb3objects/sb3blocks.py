# Comments regarding module
#
#

## Imports

## Globals

## Define
# e.g. opcode list
OPCODE_BREAKDOWN = {
    #"argument" : [],
    #"colour" : [],
    "control" : ["control_repeat", "control_repeat_until", "control_while", "control_for_each", "control_forever", "control_wait", "control_wait_until", "control_if", "control_if_else", "control_stop", "control_create_clone_of", "control_delete_this_clone", "control_get_counter", "control_incr_counter", "control_clear_counter", "control_all_at_once"],
    "data" : ["data_variable", "data_setvariableto", "data_changevariableby", "data_hidevariable", "data_showvariable", "data_listcontents", "data_addtolist", "data_deleteoflist", "data_deletealloflist", "data_insertatlist", "data_replaceitemoflist", "data_itemoflist", "data_itemnumoflist", "data_lengthoflist", "data_listcontainsitem", "data_hidelist", "data_showlist"],
    "event" : ["event_whentouchingobject", "event_broadcast", "event_broadcastandwait", "event_whengreaterthan","event_whenflagclicked", "event_whenkeypressed", "event_whenthisspriteclicked", "event_whentouchingobject", "event_whenstageclicked", "event_whenbackdropswitchesto", "event_whengreaterthan", "event_whenbroadcastreceived"],
    "looks" : ["looks_say", "looks_sayforsecs", "looks_think", "looks_thinkforsecs", "looks_show", "looks_hide", "looks_hideallsprites", "looks_switchcostumeto", "looks_switchbackdropto", "looks_switchbackdroptoandwait", "looks_nextcostume", "looks_nextbackdrop", "looks_changeeffectby", "looks_seteffectto", "looks_cleargraphiceffects", "looks_changesizeby", "looks_setsizeto", "looks_changestretchby", "looks_setstretchto", "looks_gotofrontback", "looks_goforwardbackwardlayers", "looks_size", "looks_costumenumbername", "looks_backdropnumbername"],
    #"math" : [],
    "motion" : ["motion_movesteps", "motion_gotoxy", "motion_goto", "motion_turnright", "motion_turnleft", "motion_pointindirection", "motion_pointtowards", "motion_glidesecstoxy", "motion_glideto", "motion_ifonedgebounce", "motion_setrotationstyle", "motion_changexby", "motion_setx", "motion_changeyby", "motion_sety", "motion_xposition", "motion_yposition", "motion_direction", "motion_scroll_right", "motion_scroll_up", "motion_align_scene", "motion_xscroll", "motion_yscroll"],
    "operator" : ["operator_add", "operator_subtract", "operator_multiply", "operator_divide", "operator_lt", "operator_equals", "operator_gt", "operator_and", "operator_or", "operator_not", "operator_random", "operator_join", "operator_letter_of", "operator_length", "operator_contains", "operator_mod", "operator_round", "operator_mathop"],
    "procedures" : ["procedures_definition", "procedures_call", "argument_reporter_string_number", "argument_reporter_boolean"],
    "sensing" : ["sensing_touchingobject", "sensing_touchingcolor", "sensing_coloristouchingcolor", "sensing_distanceto", "sensing_timer", "sensing_resettimer", "sensing_of", "sensing_mousex", "sensing_mousey", "sensing_setdragmode", "sensing_mousedown", "sensing_keypressed", "sensing_current", "sensing_dayssince2000", "sensing_loudness", "sensing_loud", "sensing_askandwait", "sensing_answer", "sensing_username","sensing_userid"],
    "sound" : ["sound_play", "sound_playuntildone", "sound_stopallsounds", "sound_seteffectto", "sound_changeeffectby", "sound_cleareffects", "sound_sounds_menu", "sound_beats_menu", "sound_effects_menu", "sound_setvolumeto", "sound_changevolumeby", "sound_volume"]
}

OPCODE_GROUPS = list(OPCODE_BREAKDOWN)

### Expected Arguments for Fields and Inputs for each block
# OPCODE_FIELDS_ARGS = {
#     "event_whenflagclicked" : [],
#     "event_whenkeypressed" : ['KEY_OPTION'],
#     "event_whenthisspriteclicked" : [''],
#     "event_whenbackdropswitchesto" : ['BACKDROP'],
#     "event_whenbroadcastreceived" : ['BROADCAST_OPTION'],
#     "" : [],
#     "" : [],
#     "" : [],
#     "" : [],
#     "" : [],
#     "" : [],
#     "" : [],
#     "" : [],
#     "" : [],


# }












# # Constants referring to 'primitive' blocks that are usually shadows,
# # or in the case of variables and lists, appear quite often in projects
# # math_number
# MATH_NUM_PRIMITIVE = 4 # there's no reason these constants can't collide
# # math_positive_number
# POSITIVE_NUM_PRIMITIVE = 5 # with the above, but removing duplication for clarity
# # math_whole_number
# WHOLE_NUM_PRIMITIVE = 6
# # math_integer
# INTEGER_NUM_PRIMITIVE = 7
# # math_angle
# ANGLE_NUM_PRIMITIVE = 8
# # colour_picker
# COLOR_PICKER_PRIMITIVE = 9
# # text
# TEXT_PRIMITIVE = 10
# # event_broadcast_menu
# BROADCAST_PRIMITIVE = 11
# # data_variable
# VAR_PRIMITIVE = 12
# # data_listcontents
# LIST_PRIMITIVE = 13

## Helper functions

def getOpcodeTypeFromOpcode(opcode):
    for key in OPCODE_GROUPS:
        for opcodeChoices in OPCODE_BREAKDOWN[key]:
            if(opcodeChoices == opcode):
                return key
    return "unknown"


## Class declaration

class SB3Blocks:
    #     targetName            # name of target which this block belongs to
    #     targetType            # type of target which this block belongs to
    #     uid                   # string - unique id of block
    #     opcode                # string - block type
    #     child                 # string - id of following block OR 'null' (represented in original json file as 'next')
    #     parent                # string - id of preceeding block OR 'null'
    #     input                 # array
    #     fields                # array
    #     # shadow              # True OR False
    #     topLevel              # True OR False (if block has Parent)
    #     # x                   # (only for topLevel block) x - coordinate
    #     # y                   # (only for topLevel block) y - coordinate
    #     # comment             # (only for block with comment attached) id of comment
    #     # mutation            # (only for block with a mutation) object representing the mutation

    # Constructor
    def __init__(self, targetName, targetType, uid, opcode, child, parent, inputs, fields, topLevel):
        self.blockInfoDict = {}
        self.blockInfoDict["targetName"] = targetName
        self.blockInfoDict["targetType"] = targetType
        self.blockInfoDict["uid"] = uid
        self.blockInfoDict["objectType"] = type(self)
        self.blockInfoDict["opcodeType"] = getOpcodeTypeFromOpcode(opcode)
        self.blockInfoDict["opcode"] = opcode
        self.blockInfoDict["child"] = child
        self.blockInfoDict["parent"] = parent
        self.blockInfoDict["inputs"] = inputs
        self.blockInfoDict["fields"] = fields # BROADCAST_OPTION / VARIABLE / LIST
        self.blockInfoDict["topLevel"] = topLevel

    # Class Methods
    def get_block(self):
        return self

    def get_blockInfo(self):
        return self.blockInfoDict

    def get_targetName(self):
        return self.blockInfoDict["targetName"]

    def get_targetType(self):
        return self.blockInfoDict["targetType"]

    def get_uid(self):
        return self.blockInfoDict["uid"]

    def get_objectType(self):
        return self.blockInfoDict["objectType"]

    def get_opcodeType(self):
        return self.blockInfoDict["opcodeType"]

    def get_opcode(self):
        return self.blockInfoDict["opcode"]

    def get_child(self):
        return self.blockInfoDict["child"]

    def get_parent(self):
        return self.blockInfoDict["parent"]

    def get_inputs(self):
        return self.blockInfoDict["inputs"]

    def get_fields(self): # BROADCAST_OPTION / VARIABLE / LIST
        return self.blockInfoDict["fields"]

    def get_topLevel(self):
        return self.blockInfoDict["topLevel"]
    
    def has_child(self):
        return True if self.get_child() else False
    
