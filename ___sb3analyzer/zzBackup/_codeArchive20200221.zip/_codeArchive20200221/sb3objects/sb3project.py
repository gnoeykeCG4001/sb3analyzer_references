#### Comments regarding module

### Imports
from sb3objects import sb3blocks
from sb3objects import sb3variables

class SB3Project:

    def __init__(self, tmpRawProjJsonObj):
        self.projectJsonObj = tmpRawProjJsonObj
        tmpProjectJsonObj = self.projectJsonObj

        # Sections
        self.sectionHeaderList = list(tmpProjectJsonObj)

        ## Targets
        self.targetNameList = []
        ### Variables
        ### Lists
        ### Broadcasts
        ### Blocks
        self.projectBlockList = []
        self.projectVariableList = []

        self.projectTopLevelBlockIdxList = []
        
        ### SEE IF VALID
        self.projectBlocksCallStackWithIndentInfo = [] # format [[0, blkA], [1, blkB], [2, blkC], [1, blkD], [1, blkE]]
        #Example
        #   blkA
        #       blkB
        #           blkC
        #       blkD
        #       blkE


        for indivProjectSections in self.sectionHeaderList:
            # Create project targets
            if(indivProjectSections == "targets"):
                for targetNum in range(len(tmpProjectJsonObj[indivProjectSections])):
                    tmpTargetName = tmpProjectJsonObj[indivProjectSections][targetNum]['name']
                    self.targetNameList.append(tmpTargetName) # No target object stored, might include in the future
                    tmpTargetType = "Stage" if tmpProjectJsonObj[indivProjectSections][targetNum]['isStage'] else "Sprite"
                    tmpJsonTarget = tmpProjectJsonObj[indivProjectSections][targetNum]
                    self.extractTargetParts(tmpTargetName, tmpTargetType, tmpJsonTarget)

            # Create project monitors
            if(indivProjectSections == "monitors"):
                pass
            
            # Create project extensions
            if(indivProjectSections == "extensions"):
                pass
                
            # Create project meta
            if(indivProjectSections == "meta"):
                pass

        # Create top level blocks list
        self.projectTopLevelBlockIdxList = self.create_topLevelBlocksIdxList()

    
    def extractTargetParts(self, tmpTargetName, tmpTargetType, tmpJsonTarget):
        for indivTargetSection in tmpJsonTarget:
            if(indivTargetSection == "variables"):
                for idxVariable in list(tmpJsonTarget[indivTargetSection]):
                    tmpVariableObj = tmpJsonTarget[indivTargetSection][idxVariable]
                    self.addVariablesToVariablesList(tmpTargetName, tmpTargetType, idxVariable, tmpVariableObj)

            if(indivTargetSection == "broadcasts"):
                pass

            if(indivTargetSection == "blocks"):
                for idxBlock in list(tmpJsonTarget[indivTargetSection]):
                    tmpBlockObj = tmpJsonTarget[indivTargetSection][idxBlock]
                    self.addBlocksToBlocksList(tmpTargetName, tmpTargetType, idxBlock, tmpBlockObj)

    def addBlocksToBlocksList(self, targetName, targetType, idxBlock, blockJsonObj):
        tmpOpcode = blockJsonObj['opcode']
        tmpChild = blockJsonObj['next'] if "next" in blockJsonObj else None
        tmpParent = blockJsonObj['parent'] if "parent" in blockJsonObj else None
        tmpInputs = blockJsonObj['inputs']
        tmpFields = blockJsonObj['fields']
        tmpTopLevel = blockJsonObj['topLevel']
        tmpBlockObj = sb3blocks.SB3Blocks(targetName, targetType, idxBlock, tmpOpcode, tmpChild, tmpParent, tmpInputs, tmpFields, tmpTopLevel)
        self.projectBlockList.append(tmpBlockObj)
    
    def addVariablesToVariablesList(self, targetName, targetType, idxVariable, variableJsonObj):
        tmpName = variableJsonObj[0]
        tmpValue = variableJsonObj[1]
        tmpVariableObj = sb3variables.SB3Variables(targetName, targetType, idxVariable, tmpName, tmpValue)
        self.projectVariableList.append(tmpVariableObj)

    def create_topLevelBlocksIdxList(self):
        tmpTopLevelBlockIdxList = []
        for tmpBlockObj in self.projectBlockList:
            if tmpBlockObj.get_topLevel() == True:
                tmpTopLevelBlockIdxList.append(tmpBlockObj.get_uid())
        return tmpTopLevelBlockIdxList
    
    def getBlockByIdx(self, idx):
        for tmpBlockObj in self.projectBlockList:
            if tmpBlockObj.get_uid() == idx:
                return tmpBlockObj
        return None

    ### See if valid

    def create_callStack_ofBlockIdxList(self):
        pass

    def print_blockDecode_opcode_fields_inputs(self, indent, block):
        if not block == None:

            tabSpace = "\t" * indent
            print(tabSpace + block.get_opcode(), end ='')

            tmpFieldDict = block.get_fields()
            if tmpFieldDict:
                # print(tabSpace, tmpFieldDict)

                # For presentation
                
                fieldDisp = tmpFieldDict[list(tmpFieldDict)[0]][0]

                print("(",tmpFieldDict,fieldDisp,")", end ='')
                pass
            
            print("")

            tmpInputDict = block.get_inputs()
            if tmpInputDict:
                #print(tabSpace, tmpInputDict)
                pass
                
                # listInTypes = ['CONDITION', 'SUBSTACK', 'SUBSTACK2', 'OPERAND1', 'OPERAND2', 'VOLUME', 'VALUE', 'BROADCAST_INPUT', 'SOUND_MENU', 'DURATION', 'TOUCHINGOBJECTMENU', 'FROM', 'TO', 'COSTUME', 'KEY_OPTION', 'OPERAND', 'DEGREES', 'DY', 'Y', 'X', 'DIRECTION', 'SIZE', 'TIMES', 'DX', 'CLONE_OPTION', 'ITEM', 'CHANGE', 'SECS', 'STRING', 'NUM1', 'NUM2', 'LETTER', 'STRING1', 'STRING2', 'NUM', 'QUESTION', 'MESSAGE', 'INDEX']
                listInTypes = ['CONDITION', 'SUBSTACK', 'SUBSTACK2', 'OPERAND1', 'OPERAND2', 'VALUE', 'BROADCAST_INPUT']

                for indivInTypes in listInTypes:
                    if indivInTypes in tmpInputDict:
                        self.print_blockDecode_opcode_fields_inputs(indent + 1, self.getBlockByIdx(tmpInputDict[indivInTypes][1]))

                
                


    def print_callStack_opcode_fields_inputs_Visualization(self):
        for tmpTopLevelBlockIdx in self.projectTopLevelBlockIdxList:
            tmpIndent = 1
            currBlock = self.getBlockByIdx(tmpTopLevelBlockIdx)    
            print("Sprite: " + currBlock.get_targetName())
            self.print_blockDecode_opcode_fields_inputs(tmpIndent, currBlock)
            while currBlock.has_child():
                tmpIndent = tmpIndent + 1
                currBlock = self.getBlockByIdx(currBlock.get_child())
                self.print_blockDecode_opcode_fields_inputs(tmpIndent, currBlock)
            print("")

        print("")

    def openField(self):
        pass

    
    def openInput(self):
        pass



