raw = """sound_play: this.playSound,
sound_playuntildone: this.playSoundAndWait,
sound_stopallsounds: this.stopAllSounds,
sound_seteffectto: this.setEffect,
sound_changeeffectby: this.changeEffect,
sound_cleareffects: this.clearEffects,
sound_sounds_menu: this.soundsMenu,
sound_beats_menu: this.beatsMenu,
sound_effects_menu: this.effectsMenu,
sound_setvolumeto: this.setVolume,
sound_changevolumeby: this.changeVolume,
sound_volume: this.getVolume"""

rawlines = raw.splitlines()

removedcolonlines = []

for line in rawlines:
    removedcolonlines.append((line.split(":"))[0])

print(removedcolonlines)