#### Comments regarding module
####
####


### Imports
import zipfile
import json
from sb3objects import sb3blocks
from sb3objects import sb3variables

### Globals
# sb3fileName = "LRButton-SmallBigTurn-Cat.sb3"
# sb3fileName = "Flappy Bird! remix.sb3"
sb3fileName = "motionCat.sb3"


### File Handling
sb3file = zipfile.ZipFile(sb3fileName, 'r')
projectJsonFile = sb3file.read('project.json')
projectJsonString = "".join(projectJsonFile.decode("utf-8"))

### Convert Project to Objects
projectJsonObj = json.loads(projectJsonString)

projectSectionsHeadings = ["targets", "monitors", "extensions", "meta"]

blocksList = []
variablesList = []

## Helper Functions to Extract and Convert Json Parts to Objects

# Extract Target Parts to Blocks, ...
def extractTargetParts_addToLists(targetName, targetType, targetJsonObj):
    #print(targetName)
    for idxBlock in list(targetJsonObj['blocks']):
        #print(targetJsonObj['blocks'][idxBlock])
        addBlocksToBlocksList(targetName, targetType, idxBlock, targetJsonObj['blocks'][idxBlock])
    for idxVariable in list(targetJsonObj['variables']):
        addVariablesToVariablesList(targetName, targetType, idxVariable, targetJsonObj['variables'][idxVariable])

# Extract and Convert Json Blocks to Objects and add them to List of Blocks
def addBlocksToBlocksList(targetName, targetType, idxBlock, blockJsonObj):
    tmpOpcode = blockJsonObj['opcode']
    tmpChild = blockJsonObj['next'] if "next" in blockJsonObj else None
    tmpParent = blockJsonObj['parent'] if "parent" in blockJsonObj else None
    tmpInputs = blockJsonObj['inputs']
    tmpFields = blockJsonObj['fields']
    tmpTopLevel = blockJsonObj['topLevel']
    tmpBlockObj = sb3blocks.SB3Blocks(targetName, targetType, idxBlock, tmpOpcode, tmpChild, tmpParent, tmpInputs, tmpFields, tmpTopLevel)
    blocksList.append(tmpBlockObj)

# Extract and Convert Json Variables to Objects and add them to List of Variables
def addVariablesToVariablesList(targetName, targetType, idxVariable, variableJsonObj):
    tmpName = variableJsonObj[0]
    tmpValue = variableJsonObj[1]
    tmpVariableObj = sb3variables.SB3Variables(targetName, targetType, idxVariable, tmpName, tmpValue)
    variablesList.append(tmpVariableObj)

## Conversion of Project Json Data to Objects
for indivProjectSections in projectSectionsHeadings:
    if(indivProjectSections == "targets"):
        for idxTargetInTargets in range(len(projectJsonObj[indivProjectSections])):
            tmpTargetName = projectJsonObj[indivProjectSections][idxTargetInTargets]['name']
            tmpTargetType = "Stage" if projectJsonObj[indivProjectSections][idxTargetInTargets]['isStage'] else "Sprite"
            tmpJsonTarget = projectJsonObj[indivProjectSections][idxTargetInTargets]
            extractTargetParts_addToLists(tmpTargetName, tmpTargetType, tmpJsonTarget)
        
    if(indivProjectSections == "monitors"):
        pass
    if(indivProjectSections == "extensions"):
        pass
    if(indivProjectSections == "meta"):
        pass

# Targets
    # Stage / Sprite
        # Variables
        # Broadcasts
        # Blocks

# Monitors # Extensions # Meta
print("")

# for tmpBlockObj in blocksList:
#     print(tmpBlockObj.get_blockInfoDict())
# for tmpVariableObj in variablesList:
#     print(tmpVariableObj.get_variableInfoDict())

### Analysis

# for tmpBlockObj in blocksList:
#     if((tmpBlockObj.get_blockInfoDict())["opcodeType"] == "event"):
#         print((tmpBlockObj.get_blockInfoDict())["opcode"])


blocksUidChecklist = {}
perEventBlocksStack = []

# Initializing uid checklist
#for tmpBlockObj in blocksList:
#    blocksUidChecklist[tmpBlockObj.get_blockInfo_uid()] = 0 # means programme have not "placed" the block for analysis, at the end if any block is still 0 means like "unreachable" cos not driven by events

# MAYBE to modify block object type. blockobj inputs and fields can contain stackobj
# MAYBE to do stack object type. stackobj can contain other stackobj(s)

# for tmpBlockObj in blocksList:
#     if (tmpBlockObj.get_topLevel() == True):
#         print(tmpBlockObj.get_uid() + " " + tmpBlockObj.get_opcode())

# for tmpBlockObj in blocksList:
#     print(tmpBlockObj.get_uid())
#     print(tmpBlockObj.get_opcode())
#     print(tmpBlockObj.get_topLevel())
#     print(tmpBlockObj.get_parent())
#     print(tmpBlockObj.get_child())

#     print(tmpBlockObj.get_inputs())
#     print(tmpBlockObj.get_fields())
#     print("")

def fromBlockList_getBlockObjById(uid):
    for tmpBlockObj in blocksList:
        if(tmpBlockObj.get_uid() == uid):
            return tmpBlockObj
    return None

def createTabForIndent(indent):
    tmpTabSpace = ""
    for __ in range(indent):
        tmpTabSpace = tmpTabSpace + "\t"
    return tmpTabSpace

def printBlockCallPath(indent, tmpBlockUid):
    tmpBlockIfExistElseNone = fromBlockList_getBlockObjById(tmpBlockUid)

    if not tmpBlockIfExistElseNone == None:
        tmpTabSpace = createTabForIndent(indent)

        print(tmpTabSpace + tmpBlockIfExistElseNone.get_opcode())

        tmpFieldDict  = tmpBlockIfExistElseNone.get_fields()
        if tmpFieldDict:
            print(tmpTabSpace, tmpFieldDict)

        tmpInputDict  = tmpBlockIfExistElseNone.get_inputs()
        if tmpInputDict:
            print (tmpTabSpace, tmpInputDict)
        if "SUBSTACK" in tmpInputDict:
            # print(tmpInputDict["SUBSTACK"][1])
            printBlockCallPath(indent+ 1, tmpInputDict["SUBSTACK"][1])
        if "CONDITION" in tmpInputDict:
            printBlockCallPath(indent+ 1, tmpInputDict["CONDITION"][1])
        if "SUBSTACK2" in tmpInputDict:
            # print(tmpInputDict["SUBSTACK2"][1])
            printBlockCallPath(indent + 1,tmpInputDict["SUBSTACK2"][1])


for tmpBlockObj in blocksList:
    if(tmpBlockObj.get_topLevel() == True):
        tmpIndent = 0
        tmpCurrBlock = tmpBlockObj
        print(tmpCurrBlock.get_targetName())
        #print(tmpCurrBlock.get_opcode())
        printBlockCallPath(0, tmpCurrBlock.get_uid())
        while tmpCurrBlock.has_child():
            tmpIndent = tmpIndent + 1
            tmpCurrBlock = fromBlockList_getBlockObjById(tmpCurrBlock.get_child())
            #print(tmpCurrBlock.get_opcode())
            printBlockCallPath(tmpIndent, tmpCurrBlock.get_uid())
            
        print("")
