import json

filename = "LRButton-SmallBigTurn-Cat.json"
f = open(filename,"r")

jsonString = "".join(f.readlines())

jsonObj = json.loads(jsonString)

sectionsProject = []

sectionsTargets = []
sectionsMonitors = []
sectionsExtensions = []
sectionsMeta = []

sectionsProject = list(jsonObj)

for tmpSubHead in jsonObj['targets']:
    sectionsTargets.append(list(tmpSubHead))
    
for tmpSubHead in jsonObj['monitors']:
    sectionsTargets.append(list(tmpSubHead))

for tmpSubHead in jsonObj['extensions']:
    sectionsExtensions.append(list(tmpSubHead))

for tmpSubHead in jsonObj['meta']:
    sectionsMeta.append(list(tmpSubHead))

#print(sectionsProject)

"""jsonObj
    [0] = targets, [1] = monitors
    [0] = Obj Stage, [1] = Obj Cat 2
    ['property'] = property of object
    """
#print(jsonObj[sectionsProject[0]][1]["name"])


#print(sectionsTargets)
#print(sectionsMonitors)
#print(sectionsExtensions)
#print(sectionsMeta)

print(jsonObj[sectionsProject[0]][1]['name'])
#print(jsonObj[sectionsProject[0]][1]['blocks'])

tmpBlocksId =[]

for blockId in jsonObj[sectionsProject[0]][1]['blocks']:
    tmpBlocksId.append(blockId)

#print(tmpBlocksId)

for blockIdListIdx in range(len(tmpBlocksId)):
    print(jsonObj[sectionsProject[0]][1]['blocks'][tmpBlocksId[blockIdListIdx]]['opcode'])

    
