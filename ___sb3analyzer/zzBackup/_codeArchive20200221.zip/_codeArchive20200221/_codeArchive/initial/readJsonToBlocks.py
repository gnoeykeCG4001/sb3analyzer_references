import json

filename = "LRButton-SmallBigTurn-Cat.json"
f = open(filename,"r")

jsonString = "".join(f.readlines())

jsonObj = json.loads(jsonString)

sectionsProject = []

sectionsTargets = []
sectionsMonitors = []
sectionsExtensions = []
sectionsMeta = []

sectionsProject = list(jsonObj)

for tmpSubHead in jsonObj['targets']:
    sectionsTargets.append(list(tmpSubHead))
    
for tmpSubHead in jsonObj['monitors']:
    sectionsTargets.append(list(tmpSubHead))

for tmpSubHead in jsonObj['extensions']:
    sectionsExtensions.append(list(tmpSubHead))

for tmpSubHead in jsonObj['meta']:
    sectionsMeta.append(list(tmpSubHead))

#print(sectionsProject)

"""jsonObj
    [0] = targets, [1] = monitors
    [0] = Obj Stage, [1] = Obj Cat 2
    ['property'] = property of object
    """
#print(jsonObj[sectionsProject[0]][1]["name"])


#print(sectionsTargets)
#print(sectionsMonitors)
#print(sectionsExtensions)
#print(sectionsMeta)

#print(jsonObj[sectionsProject[0]][1]['blocks'])

class Blocks:
    def __init__(self, container, uid,opcode,child,parent,inputs,fields, topLevel):
        self.container = container #stage/sprite where parts are situated in
        self.uid = uid
        self.opcode = opcode
        self.child = child #next
        self.parent = parent
        self.inputs = inputs
        self.fields = fields
        self.topLevel = topLevel

blocksList = []

for targetsNum in range(len(jsonObj[sectionsProject[0]])):
    
    tmpVarId =[]
    tmpBlocksId =[]
    
    print(jsonObj[sectionsProject[0]][targetsNum]['name'])

    print("variables")
    for varId in jsonObj[sectionsProject[0]][targetsNum]['variables']:
        tmpVarId.append(varId)

    for varIdListIdx in range(len(tmpVarId)):
        print(jsonObj[sectionsProject[0]][targetsNum]['variables'][tmpVarId[varIdListIdx]])
        
    print("blocks")
    for blockId in jsonObj[sectionsProject[0]][targetsNum]['blocks']:
        tmpBlocksId.append(blockId)

    #print(tmpBlocksId)
    
    for blockIdListIdx in range(len(tmpBlocksId)):
        #iterate through all blocks of container
        print(jsonObj[sectionsProject[0]][targetsNum]['blocks'][tmpBlocksId[blockIdListIdx]]['opcode'])
        
        tmpContainer = jsonObj[sectionsProject[0]][targetsNum]['name']
        tmpUid = tmpBlocksId[blockIdListIdx]
        tmpOpcode = jsonObj[sectionsProject[0]][targetsNum]['blocks'][tmpBlocksId[blockIdListIdx]]['opcode']
        tmpChild = jsonObj[sectionsProject[0]][targetsNum]['blocks'][tmpBlocksId[blockIdListIdx]]['next']
        tmpParent = jsonObj[sectionsProject[0]][targetsNum]['blocks'][tmpBlocksId[blockIdListIdx]]['parent']
        tmpInputs = jsonObj[sectionsProject[0]][targetsNum]['blocks'][tmpBlocksId[blockIdListIdx]]['inputs']
        tmpFields = jsonObj[sectionsProject[0]][targetsNum]['blocks'][tmpBlocksId[blockIdListIdx]]['fields']
        tmpTopLevel = jsonObj[sectionsProject[0]][targetsNum]['blocks'][tmpBlocksId[blockIdListIdx]]['topLevel']
        
        tmpBlock = Blocks(tmpContainer, tmpUid, tmpOpcode, tmpChild, tmpParent, tmpInputs, tmpFields, tmpTopLevel)
        blocksList.append(tmpBlock)

    print("")

print(len(blocksList))
print(blocksList)







    
