f = open("tmp.txt", "r")

fileinf = f.read()

f.close()

f = open("tmp.txt", "w")

f.write(fileinf.replace("\'","\""))

f.close()