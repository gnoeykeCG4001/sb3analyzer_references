#### Comments regarding module

### Imports
import json
from sb3objects import sb3project

def createProjectObjectFromJsonString(projectJsonString):

    projectJsonObj = json.loads(projectJsonString)

    # Create project object with raw project json data
    tmpProject = sb3project.SB3Project(projectJsonObj)

    return tmpProject # return SB3Project Object
