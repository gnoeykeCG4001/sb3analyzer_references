#### Comments regarding module

### Imports
import zipfile
from sb3serializer import sb3serializer
from sb3analyzer import sb3analyzer
from sb3objects import sb3blocks

### Globals
sb3fileName = "CatJumpJump.sb3"
# sb3fileName = "LRButton-SmallBigTurn-Cat.sb3"
# sb3fileName = "Flappy Bird! remix.sb3"
# sb3fileName = "motionCat.sb3"


### File Handling
sb3file = zipfile.ZipFile(sb3fileName, 'r')
projectJsonFile = sb3file.read('project.json')
# projectJsonString = "".join(projectJsonFile.decode("utf-8"))
projectJsonString = "".join(projectJsonFile.decode("ascii","ignore")) # protection from using unknown unicode characters

### Create Project Assets
Project = sb3serializer.createProjectObjectFromJsonString(projectJsonString)

# for blkObj in Project.projectBlockList:
#     print(blkObj.get_blockInfo())
# for varObj in Project.projectVariableList:
#     print(varObj.get_variableInfo())



# for blkObj in Project.projectBlockList:
#     if blkObj.get_inputs() or blkObj.get_fields():
#     # if blkObj.get_fields():
#     # if blkObj.get_inputs():
#         print(blkObj.get_opcode())
#         if blkObj.get_inputs():
#             print("\tInputs:\t", blkObj.get_inputs())
#         if blkObj.get_fields():
#             print("\tFields:\t", blkObj.get_fields())



# tmpInputKey = []
# tmpFieldKey = []
# for blkObj in Project.projectBlockList:
#     if blkObj.get_inputs() or blkObj.get_fields():
#         if blkObj.get_inputs():
#             #print("\tInputs:\t", blkObj.get_inputs())
#             tmpInputList = list(blkObj.get_inputs())
#             for indivInParam in tmpInputList:
#                 if not (indivInParam in tmpInputKey):
#                     tmpInputKey.append(indivInParam)
#         if blkObj.get_fields():
#             tmpFieldList = list(blkObj.get_fields())
#             for indivFieldParam in tmpFieldList:
#                 if not (indivFieldParam in tmpFieldKey):
#                     tmpFieldKey.append(indivFieldParam)
# print(tmpInputKey)
# print("")
# print(tmpFieldKey)

Project.print_callStack_opcode_fields_inputs_Visualization()