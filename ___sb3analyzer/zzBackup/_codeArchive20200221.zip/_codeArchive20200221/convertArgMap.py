specMap = {
    'forward:': {
        "opcode" : 'motion_movesteps',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'STEPS'
            }
        ]
    },
    'turnRight:': {
        "opcode" : 'motion_turnright',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'DEGREES'
            }
        ]
    },
    'turnLeft:': {
        "opcode" : 'motion_turnleft',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'DEGREES'
            }
        ]
    },
    'heading:': {
        "opcode" : 'motion_pointindirection',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_angle',
                "inputName" : 'DIRECTION'
            }
        ]
    },
    'pointTowards:': {
        "opcode" : 'motion_pointtowards',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'motion_pointtowards_menu',
                "inputName" : 'TOWARDS'
            }
        ]
    },
    'gotoX:y:': {
        "opcode" : 'motion_gotoxy',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'X'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'Y'
            }
        ]
    },
    'gotoSpriteOrMouse:': {
        "opcode" : 'motion_goto',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'motion_goto_menu',
                "inputName" : 'TO'
            }
        ]
    },
    'glideSecs:toX:y:elapsed:from:': {
        "opcode" : 'motion_glidesecstoxy',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'SECS'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'X'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'Y'
            }
        ]
    },
    'changeXposBy:': {
        "opcode" : 'motion_changexby',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'DX'
            }
        ]
    },
    'xpos:': {
        "opcode" : 'motion_setx',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'X'
            }
        ]
    },
    'changeYposBy:': {
        "opcode" : 'motion_changeyby',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'DY'
            }
        ]
    },
    'ypos:': {
        "opcode" : 'motion_sety',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'Y'
            }
        ]
    },
    'bounceOffEdge': {
        "opcode" : 'motion_ifonedgebounce',
        "argMap" : [
        ]
    },
    'setRotationStyle': {
        "opcode" : 'motion_setrotationstyle',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'STYLE'
            }
        ]
    },
    'xpos': {
        "opcode" : 'motion_xposition',
        "argMap" : [
        ]
    },
    'ypos': {
        "opcode" : 'motion_yposition',
        "argMap" : [
        ]
    },
    'heading': {
        "opcode" : 'motion_direction',
        "argMap" : [
        ]
    },
    'scrollRight': {
        "opcode" : 'motion_scroll_right',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'DISTANCE'
            }
        ]
    },
    'scrollUp': {
        "opcode" : 'motion_scroll_up',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'DISTANCE'
            }
        ]
    },
    'scrollAlign': {
        "opcode" : 'motion_align_scene',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'ALIGNMENT'
            }
        ]
    },
    'xScroll': {
        "opcode" : 'motion_xscroll',
        "argMap" : [
        ]
    },
    'yScroll': {
        "opcode" : 'motion_yscroll',
        "argMap" : [
        ]
    },
    'say:duration:elapsed:from:': {
        "opcode" : 'looks_sayforsecs',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'MESSAGE'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'SECS'
            }
        ]
    },
    'say:': {
        "opcode" : 'looks_say',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'MESSAGE'
            }
        ]
    },
    'think:duration:elapsed:from:': {
        "opcode" : 'looks_thinkforsecs',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'MESSAGE'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'SECS'
            }
        ]
    },
    'think:': {
        "opcode" : 'looks_think',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'MESSAGE'
            }
        ]
    },
    'show': {
        "opcode" : 'looks_show',
        "argMap" : [
        ]
    },
    'hide': {
        "opcode" : 'looks_hide',
        "argMap" : [
        ]
    },
    'hideAll': {
        "opcode" : 'looks_hideallsprites',
        "argMap" : [
        ]
    },
    'lookLike:': {
        "opcode" : 'looks_switchcostumeto',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'looks_costume',
                "inputName" : 'COSTUME'
            }
        ]
    },
    'nextCostume': {
        "opcode" : 'looks_nextcostume',
        "argMap" : [
        ]
    },
    'startScene': {
        "opcode" : 'looks_switchbackdropto',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'looks_backdrops',
                "inputName" : 'BACKDROP'
            }
        ]
    },
    'changeGraphicEffect:by:': {
        "opcode" : 'looks_changeeffectby',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'EFFECT'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'CHANGE'
            }
        ]
    },
    'setGraphicEffect:to:': {
        "opcode" : 'looks_seteffectto',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'EFFECT'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'VALUE'
            }
        ]
    },
    'filterReset': {
        "opcode" : 'looks_cleargraphiceffects',
        "argMap" : [
        ]
    },
    'changeSizeBy:': {
        "opcode" : 'looks_changesizeby',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'CHANGE'
            }
        ]
    },
    'setSizeTo:': {
        "opcode" : 'looks_setsizeto',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'SIZE'
            }
        ]
    },
    'changeStretchBy:': {
        "opcode" : 'looks_changestretchby',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'CHANGE'
            }
        ]
    },
    'setStretchTo:': {
        "opcode" : 'looks_setstretchto',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'STRETCH'
            }
        ]
    },
    'comeToFront': {
        "opcode" : 'looks_gotofrontback',
        "argMap" : [
        ]
    },
    'goBackByLayers:': {
        "opcode" : 'looks_goforwardbackwardlayers',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_integer',
                "inputName" : 'NUM'
            }
        ]
    },
    'costumeIndex': {
        "opcode" : 'looks_costumenumbername',
        "argMap" : [
        ]
    },
    'costumeName': {
        "opcode" : 'looks_costumenumbername',
        "argMap" : [
        ]
    },
    'sceneName': {
        "opcode" : 'looks_backdropnumbername',
        "argMap" : [
        ]
    },
    'scale': {
        "opcode" : 'looks_size',
        "argMap" : [
        ]
    },
    'startSceneAndWait': {
        "opcode" : 'looks_switchbackdroptoandwait',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'looks_backdrops',
                "inputName" : 'BACKDROP'
            }
        ]
    },
    'nextScene': {
        "opcode" : 'looks_nextbackdrop',
        "argMap" : [
        ]
    },
    'backgroundIndex': {
        "opcode" : 'looks_backdropnumbername',
        "argMap" : [
        ]
    },
    'playSound:': {
        "opcode" : 'sound_play',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'sound_sounds_menu',
                "inputName" : 'SOUND_MENU'
            }
        ]
    },
    'doPlaySoundAndWait': {
        "opcode" : 'sound_playuntildone',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'sound_sounds_menu',
                "inputName" : 'SOUND_MENU'
            }
        ]
    },
    'stopAllSounds': {
        "opcode" : 'sound_stopallsounds',
        "argMap" : [
        ]
    },
    'playDrum': {
        "opcode" : 'music_playDrumForBeats',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'music_menu_DRUM',
                "inputName" : 'DRUM'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'BEATS'
            }
        ]
    },
    'drum:duration:elapsed:from:': {
        "opcode" : 'music_midiPlayDrumForBeats',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'DRUM'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'BEATS'
            }
        ]
    },
    'rest:elapsed:from:': {
        "opcode" : 'music_restForBeats',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'BEATS'
            }
        ]
    },
    'noteOn:duration:elapsed:from:': {
        "opcode" : 'music_playNoteForBeats',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'note',
                "inputName" : 'NOTE'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'BEATS'
            }
        ]
    },
    'instrument:': {
        "opcode" : 'music_setInstrument',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'music_menu_INSTRUMENT',
                "inputName" : 'INSTRUMENT'
            }
        ]
    },
    'midiInstrument:': {
        "opcode" : 'music_midiSetInstrument',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'INSTRUMENT'
            }
        ]
    },
    'changeVolumeBy:': {
        "opcode" : 'sound_changevolumeby',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'VOLUME'
            }
        ]
    },
    'setVolumeTo:': {
        "opcode" : 'sound_setvolumeto',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'VOLUME'
            }
        ]
    },
    'volume': {
        "opcode" : 'sound_volume',
        "argMap" : [
        ]
    },
    'changeTempoBy:': {
        "opcode" : 'music_changeTempo',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'TEMPO'
            }
        ]
    },
    'setTempoTo:': {
        "opcode" : 'music_setTempo',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'TEMPO'
            }
        ]
    },
    'tempo': {
        "opcode" : 'music_getTempo',
        "argMap" : [
        ]
    },
    'clearPenTrails': {
        "opcode" : 'pen_clear',
        "argMap" : [
        ]
    },
    'stampCostume': {
        "opcode" : 'pen_stamp',
        "argMap" : [
        ]
    },
    'putPenDown': {
        "opcode" : 'pen_penDown',
        "argMap" : [
        ]
    },
    'putPenUp': {
        "opcode" : 'pen_penUp',
        "argMap" : [
        ]
    },
    'penColor:': {
        "opcode" : 'pen_setPenColorToColor',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'colour_picker',
                "inputName" : 'COLOR'
            }
        ]
    },
    'changePenHueBy:': {
        "opcode" : 'pen_changePenHueBy',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'HUE'
            }
        ]
    },
    'setPenHueTo:': {
        "opcode" : 'pen_setPenHueToNumber',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'HUE'
            }
        ]
    },
    'changePenShadeBy:': {
        "opcode" : 'pen_changePenShadeBy',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'SHADE'
            }
        ]
    },
    'setPenShadeTo:': {
        "opcode" : 'pen_setPenShadeToNumber',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'SHADE'
            }
        ]
    },
    'changePenSizeBy:': {
        "opcode" : 'pen_changePenSizeBy',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'SIZE'
            }
        ]
    },
    'penSize:': {
        "opcode" : 'pen_setPenSizeTo',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'SIZE'
            }
        ]
    },
    'senseVideoMotion': {
        "opcode" : 'videoSensing_videoOn',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'videoSensing_menu_ATTRIBUTE',
                "inputName" : 'ATTRIBUTE'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'videoSensing_menu_SUBJECT',
                "inputName" : 'SUBJECT'
            }
        ]
    },
    'whenGreenFlag': {
        "opcode" : 'event_whenflagclicked',
        "argMap" : [
        ]
    },
    'whenKeyPressed': {
        "opcode" : 'event_whenkeypressed',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'KEY_OPTION'
            }
        ]
    },
    'whenClicked': {
        "opcode" : 'event_whenthisspriteclicked',
        "argMap" : [
        ]
    },
    'whenSceneStarts': {
        "opcode" : 'event_whenbackdropswitchesto',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'BACKDROP'
            }
        ]
    },

    'whenSensorGreaterThan_VideoMotion': {
        "opcode" : 'videoSensing_whenMotionGreaterThan',
        "argMap" : [
            # skip the first arg, since we converted to a video specific sensing block
            {},
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'REFERENCE'
            }
        ]
    },

    'whenSensorGreaterThan_N0tVideoMotion': {
        "opcode" : 'event_whengreaterthan',
            "argMap" : [
                {
                    "typeInOrFi" : 'field',
                    "fieldName" : 'WHENGREATERTHANMENU'
                },
                {
                    "typeInOrFi" : 'input',
                    "inputOp" : 'math_number',
                    "inputName" : 'VALUE'
                }
            ]
    },

    'whenIReceive': {
        "opcode" : 'event_whenbroadcastreceived',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'BROADCAST_OPTION',
                "variabletype" : "sb3variables.SB3Variables.BROADCAST_MESSAGE_TYPE"
            }
        ]
    },
    'broadcast:': {
        "opcode" : 'event_broadcast',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'event_broadcast_menu',
                "inputName" : 'BROADCAST_INPUT',
                "variabletype" : "sb3variables.SB3Variables.BROADCAST_MESSAGE_TYPE"
            }
        ]
    },
    'doBroadcastAndWait': {
        "opcode" : 'event_broadcastandwait',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'event_broadcast_menu',
                "inputName" : 'BROADCAST_INPUT',
                "variabletype" : "sb3variables.SB3Variables.BROADCAST_MESSAGE_TYPE"
            }
        ]
    },
    'wait:elapsed:from:': {
        "opcode" : 'control_wait',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_positive_number',
                "inputName" : 'DURATION'
            }
        ]
    },
    'doRepeat': {
        "opcode" : 'control_repeat',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_whole_number',
                "inputName" : 'TIMES'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'substack',
                "inputName" : 'SUBSTACK'
            }
        ]
    },
    'doForever': {
        "opcode" : 'control_forever',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'substack',
                "inputName" : 'SUBSTACK'
            }
        ]
    },
    'doIf': {
        "opcode" : 'control_if',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'CONDITION'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'substack',
                "inputName" : 'SUBSTACK'
            }
        ]
    },
    'doIfElse': {
        "opcode" : 'control_if_else',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'CONDITION'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'substack',
                "inputName" : 'SUBSTACK'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'substack',
                "inputName" : 'SUBSTACK2'
            }
        ]
    },
    'doWaitUntil': {
        "opcode" : 'control_wait_until',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'CONDITION'
            }
        ]
    },
    'doUntil': {
        "opcode" : 'control_repeat_until',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'CONDITION'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'substack',
                "inputName" : 'SUBSTACK'
            }
        ]
    },
    'doWhile': {
        "opcode" : 'control_while',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'CONDITION'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'substack',
                "inputName" : 'SUBSTACK'
            }
        ]
    },
    'doForLoop': {
        "opcode" : 'control_for_each',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'VARIABLE'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'VALUE'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'substack',
                "inputName" : 'SUBSTACK'
            }
        ]
    },
    'stopScripts': {
        "opcode" : 'control_stop',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'STOP_OPTION'
            }
        ]
    },
    'whenCloned': {
        "opcode" : 'control_start_as_clone',
        "argMap" : [
        ]
    },
    'createCloneOf': {
        "opcode" : 'control_create_clone_of',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'control_create_clone_of_menu',
                "inputName" : 'CLONE_OPTION'
            }
        ]
    },
    'deleteClone': {
        "opcode" : 'control_delete_this_clone',
        "argMap" : [
        ]
    },
    'COUNT': {
        "opcode" : 'control_get_counter',
        "argMap" : [
        ]
    },
    'INCR_COUNT': {
        "opcode" : 'control_incr_counter',
        "argMap" : [
        ]
    },
    'CLR_COUNT': {
        "opcode" : 'control_clear_counter',
        "argMap" : [
        ]
    },
    'warpSpeed': {
        "opcode" : 'control_all_at_once',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'substack',
                "inputName" : 'SUBSTACK'
            }
        ]
    },
    'touching:': {
        "opcode" : 'sensing_touchingobject',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'sensing_touchingobjectmenu',
                "inputName" : 'TOUCHINGOBJECTMENU'
            }
        ]
    },
    'touchingColor:': {
        "opcode" : 'sensing_touchingcolor',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'colour_picker',
                "inputName" : 'COLOR'
            }
        ]
    },
    'color:sees:': {
        "opcode" : 'sensing_coloristouchingcolor',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'colour_picker',
                "inputName" : 'COLOR'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'colour_picker',
                "inputName" : 'COLOR2'
            }
        ]
    },
    'distanceTo:': {
        "opcode" : 'sensing_distanceto',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'sensing_distancetomenu',
                "inputName" : 'DISTANCETOMENU'
            }
        ]
    },
    'doAsk': {
        "opcode" : 'sensing_askandwait',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'QUESTION'
            }
        ]
    },
    'answer': {
        "opcode" : 'sensing_answer',
        "argMap" : [
        ]
    },
    'keyPressed:': {
        "opcode" : 'sensing_keypressed',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'sensing_keyoptions',
                "inputName" : 'KEY_OPTION'
            }
        ]
    },
    'mousePressed': {
        "opcode" : 'sensing_mousedown',
        "argMap" : [
        ]
    },
    'mouseX': {
        "opcode" : 'sensing_mousex',
        "argMap" : [
        ]
    },
    'mouseY': {
        "opcode" : 'sensing_mousey',
        "argMap" : [
        ]
    },
    'soundLevel': {
        "opcode" : 'sensing_loudness',
        "argMap" : [
        ]
    },
    'isLoud': {
        "opcode" : 'sensing_loud',
        "argMap" : [
        ]
    },
    # 'senseVideoMotion': {
    #     "opcode" : 'sensing_videoon',
    #     "argMap" : [
    #         {
    #             "typeInOrFi" : 'input',
    #             "inputOp" : 'sensing_videoonmenuone',
    #             "inputName" : 'VIDEOONMENU1'
    #         },
    #         {
    #             "typeInOrFi" : 'input',
    #             "inputOp" : 'sensing_videoonmenutwo',
    #             "inputName" : 'VIDEOONMENU2'
    #         }
    #     ]
    # },
    'setVideoState': {
        "opcode" : 'videoSensing_videoToggle',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'videoSensing_menu_VIDEO_STATE',
                "inputName" : 'VIDEO_STATE'
            }
        ]
    },
    'setVideoTransparency': {
        "opcode" : 'videoSensing_setVideoTransparency',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'TRANSPARENCY'
            }
        ]
    },
    'timer': {
        "opcode" : 'sensing_timer',
        "argMap" : [
        ]
    },
    'timerReset': {
        "opcode" : 'sensing_resettimer',
        "argMap" : [
        ]
    },
    'getAttribute:of:': {
        "opcode" : 'sensing_of',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'PROPERTY'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'sensing_of_object_menu',
                "inputName" : 'OBJECT'
            }
        ]
    },
    'timeAndDate': {
        "opcode" : 'sensing_current',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'CURRENTMENU'
            }
        ]
    },
    'timestamp': {
        "opcode" : 'sensing_dayssince2000',
        "argMap" : [
        ]
    },
    'getUserName': {
        "opcode" : 'sensing_username',
        "argMap" : [
        ]
    },
    'getUserId': {
        "opcode" : 'sensing_userid',
        "argMap" : [
        ]
    },
    '+': {
        "opcode" : 'operator_add',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM2'
            }
        ]
    },
    '-': {
        "opcode" : 'operator_subtract',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM2'
            }
        ]
    },
    '*': {
        "opcode" : 'operator_multiply',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM2'
            }
        ]
    },
    '/': {
        "opcode" : 'operator_divide',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM2'
            }
        ]
    },
    'randomFrom:to:': {
        "opcode" : 'operator_random',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'FROM'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'TO'
            }
        ]
    },
    '<': {
        "opcode" : 'operator_lt',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'OPERAND1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'OPERAND2'
            }
        ]
    },
    '=': {
        "opcode" : 'operator_equals',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'OPERAND1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'OPERAND2'
            }
        ]
    },
    '>': {
        "opcode" : 'operator_gt',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'OPERAND1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'OPERAND2'
            }
        ]
    },
    '&': {
        "opcode" : 'operator_and',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'OPERAND1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'OPERAND2'
            }
        ]
    },
    '|': {
        "opcode" : 'operator_or',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'OPERAND1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'OPERAND2'
            }
        ]
    },
    'not': {
        "opcode" : 'operator_not',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'boolean',
                "inputName" : 'OPERAND'
            }
        ]
    },
    'concatenate:with:': {
        "opcode" : 'operator_join',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'STRING1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'STRING2'
            }
        ]
    },
    'letter:of:': {
        "opcode" : 'operator_letter_of',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_whole_number',
                "inputName" : 'LETTER'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'STRING'
            }
        ]
    },
    'stringLength:': {
        "opcode" : 'operator_length',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'STRING'
            }
        ]
    },
    '%': {
        "opcode" : 'operator_mod',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM1'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM2'
            }
        ]
    },
    'rounded': {
        "opcode" : 'operator_round',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM'
            }
        ]
    },
    'computeFunction:of:': {
        "opcode" : 'operator_mathop',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'OPERATOR'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'NUM'
            }
        ]
    },
    'readVariable': {
        "opcode" : 'data_variable',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'VARIABLE',
                "variabletype" : "sb3variables.SB3Variables.SCALAR_TYPE"
            }
        ]
    },
    # Scratch 2 uses this alternative variable getter opcode only in monitors,
    # blocks use the `readVariable` opcode above.
    'getVar:': {
        "opcode" : 'data_variable',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'VARIABLE',
                "variabletype" : "sb3variables.SB3Variables.SCALAR_TYPE"
            }
        ]
    },
    'setVar:to:': {
        "opcode" : 'data_setvariableto',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'VARIABLE',
                "variabletype" : "sb3variables.SB3Variables.SCALAR_TYPE"
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'VALUE'
            }
        ]
    },
    'changeVar:by:': {
        "opcode" : 'data_changevariableby',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'VARIABLE',
                "variabletype" : "sb3variables.SB3Variables.SCALAR_TYPE"
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_number',
                "inputName" : 'VALUE'
            }
        ]
    },
    'showVariable:': {
        "opcode" : 'data_showvariable',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'VARIABLE',
                "variabletype" : "sb3variables.SB3Variables.SCALAR_TYPE"
            }
        ]
    },
    'hideVariable:': {
        "opcode" : 'data_hidevariable',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'VARIABLE',
                "variabletype" : "sb3variables.SB3Variables.SCALAR_TYPE"
            }
        ]
    },
    'contentsOfList:': {
        "opcode" : 'data_listcontents',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            }
        ]
    },
    'append:toList:': {
        "opcode" : 'data_addtolist',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'ITEM'
            },
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            }
        ]
    },
    'deleteLine:ofList:': {
        "opcode" : 'data_deleteoflist',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_integer',
                "inputName" : 'INDEX'
            },
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            }
        ]
    },
    'insert:at:ofList:': {
        "opcode" : 'data_insertatlist',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'ITEM'
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_integer',
                "inputName" : 'INDEX'
            },
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            }
        ]
    },
    'setLine:ofList:to:': {
        "opcode" : 'data_replaceitemoflist',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_integer',
                "inputName" : 'INDEX'
            },
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'ITEM'
            }
        ]
    },
    'getLine:ofList:': {
        "opcode" : 'data_itemoflist',
        "argMap" : [
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'math_integer',
                "inputName" : 'INDEX'
            },
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            }
        ]
    },
    'lineCountOfList:': {
        "opcode" : 'data_lengthoflist',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            }
        ]
    },
    'list:contains:': {
        "opcode" : 'data_listcontainsitem',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            },
            {
                "typeInOrFi" : 'input',
                "inputOp" : 'text',
                "inputName" : 'ITEM'
            }
        ]
    },
    'showList:': {
        "opcode" : 'data_showlist',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            }
        ]
    },
    'hideList:': {
        "opcode" : 'data_hidelist',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'LIST',
                "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
            }
        ]
    },
    'procDef': {
        "opcode" : 'procedures_definition',
        "argMap" : []
    },
    'getParam': {
        # Doesn't map to single opcode. Import step assigns final correct opcode.
        "opcode" : 'argument_reporter_string_number',
        "argMap" : [
            {
                "typeInOrFi" : 'field',
                "fieldName" : 'VALUE'
            }
        ]
    },
    'call': {
        "opcode" : 'procedures_call',
        "argMap" : []
    }
}

sb2key = list(specMap)

# remove sb2 key

sb3ArgMap = {}

# 'insert:at:ofList:': {
#     "opcode" : 'data_insertatlist',
#     "argMap" : [
#         {
#             "typeInOrFi" : 'input',
#             "inputOp" : 'text',
#             "inputName" : 'ITEM'
#         },
#         {
#             "typeInOrFi" : 'input',
#             "inputOp" : 'math_integer',
#             "inputName" : 'INDEX'
#         },
#         {
#             "typeInOrFi" : 'field',
#             "fieldName" : 'LIST',
#             "variabletype" : "sb3variables.SB3Variables.LIST_TYPE"
#         }
#     ]
# },

for indivSb2 in sb2key:
    argMap = []
    opcode = (specMap[indivSb2])['opcode']
    if (specMap[indivSb2])['argMap']:
        argMap = (specMap[indivSb2])['argMap']
    sb3ArgMap[opcode] = argMap
    # break    

print(sb3ArgMap)
