import json

filename = "testDeconstructionFBjsonSrc.json"
f = open(filename,"r")

jsonString = "".join(f.readlines())

jsonObj = json.loads(jsonString)

listBlocksObjs = list(jsonObj["blocks"])
#listBlocksObjs = jsonObj["blocks"].keys()

listBlockNames = list()

for blockNames in listBlocksObjs:
    listBlockNames.append(blockNames)

print(listBlockNames)


