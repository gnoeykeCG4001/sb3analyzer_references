# Comments regarding module
#
#

## Imports
from sb3objects import sb3block

## Globals

## Define

## Helper functions

## Class declaration

class SB3Target:       
    def __init__(self, targetJsonObj):
        self.isStage = targetJsonObj['isStage']
        self.type = "stage" if targetJsonObj['isStage'] else "sprite"
        self.name = targetJsonObj['name']
        
        self.targetBlockList = []

        # extract block and add to list
        for blockIdx in targetJsonObj['blocks']:
            self.targetBlockList.append(sb3block.SB3Block(self.name, blockIdx, targetJsonObj['blocks'][blockIdx]))

    # Class Methods
    def get_self(self):
        return self

    def get_isStage(self):
        return self.isStage

    def get_type(self):
        return self.type

    def get_name(self):
        return self.name

    def get_blockList(self):
        return self.targetBlockList
    
    def getBlock_byId(self, idx):
        for tmpBlockObj in self.get_blockList():
            if tmpBlockObj.get_idx() == idx:
                return tmpBlockObj
        return None

    def containsBlock_byId(self, idx):
        for tmpBlockObj in self.get_blockList():
            if tmpBlockObj.get_idx() == idx:
                return True
        return False
    
    def traversalEngin_print(self):
        print("# " + str(self.get_name()))
        print("# -----")
        for indivBlock in self.get_blockList():
            if indivBlock.get_topLevel() == True:        
                print(self.unpack(0, [0, indivBlock.get_idx()]))
                print()

    def unpack(self, indent, type_val_arr):
        if type_val_arr[0] == 0: # is a reference
            if self.containsBlock_byId(type_val_arr[1]): # is a block
                currBlock = self.getBlock_byId(type_val_arr[1])
                currBlock_nextIdx = currBlock.get_next()
                currBlock_opcode = currBlock.get_opcode()
                currBlock_inputDict = currBlock.get_blockInputDict()
                currBlock_fieldDict = currBlock.get_blockFieldDict()

                if(currBlock_nextIdx != None):
                    return str(self.decode_blockInput(indent, currBlock_opcode, currBlock_inputDict, currBlock_fieldDict)) + self.unpack(indent, [0, currBlock_nextIdx])
                else:
                    return str(self.decode_blockInput(indent, currBlock_opcode, currBlock_inputDict, currBlock_fieldDict))
        else:
            # default return #1 of typevalarr
            return str(type_val_arr[1])
        

        return "default"
    
    def decode_blockInput(self, indent, opcode, inputDict, fieldDict):
        if opcode == 'event_whenflagclicked':
            return str("event: when flag clicked\n")
        if opcode == 'data_setvariableto':
            return str(self.unpack(indent, fieldDict['VARIABLE'])) + " = " + str(self.unpack(indent, inputDict['VALUE']))
        if opcode == 'data_changevariableby':
            return str(self.unpack(indent, fieldDict['VARIABLE'])) + " += " + str(self.unpack(indent, inputDict['VALUE']))
        if opcode == 'operator_equals':
            return str(self.unpack(indent, inputDict['OPERAND1'])) + " == " + str(self.unpack(indent, inputDict['OPERAND2']))
        if opcode == 'operator_lt':
            return str(self.unpack(indent, inputDict['OPERAND1'])) + " < " + str(self.unpack(indent, inputDict['OPERAND2']))
        if opcode == 'control_if':
            return self.tabString(indent) + str("if " + self.unpack(indent, inputDict['CONDITION'])) + ":\n" + self.tabString(indent + 1) + str(self.unpack(indent+1, inputDict['SUBSTACK']))
        if opcode == 'control_if_else':
            return self.tabString(indent) + str("if " + self.unpack(indent, inputDict['CONDITION'])) + ":\n" + self.tabString(indent + 1) + str(self.unpack(indent+1, inputDict['SUBSTACK'])) + "\n" + self.tabString(indent) + "else:\n" + self.tabString(indent + 1) + str(self.unpack(indent+1, inputDict['SUBSTACK2']))
        if opcode == 'control_repeat_until':
            return self.tabString(indent) + str("while " + self.unpack(indent, inputDict['CONDITION'])) + ":\n" + self.tabString(indent + 1) + str(self.unpack(indent+1, inputDict['SUBSTACK']))
        if opcode == 'control_repeat':
            return self.tabString(indent) + str("for i in range(" + self.unpack(indent, inputDict['TIMES'])) + "):\n" + self.tabString(indent + 1) + str(self.unpack(indent+1, inputDict['SUBSTACK']))
        if opcode == 'control_wait':
            return self.tabString(indent + 1) + "wait(" + str(self.unpack(indent, inputDict['DURATION'])) + ")"

        return opcode

        '''
        elif opcode == '':
            pass
        elif opcode == '':
            pass
        else:
            pass
        '''
    def tabString(self, num):
        tabStr = "\t" * num
        return tabStr