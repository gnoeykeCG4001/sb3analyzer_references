# Comments regarding module
#
#

## Imports

## Globals

## Define

## Class declaration

class SB3Variables:
    #     targetName            # name of target which this block belongs to
    #     targetType            # type of target which this block belongs to
    #     uid                   # string - unique id of variable
    #     name                  # string - name of variable
    #     value                 # string - value of variable

    # Constructor
    def __init__(self, targetName, targetType, uid, name, value):
        self.variableInfoDict = {}
        self.variableInfoDict["targetName"] = targetName
        self.variableInfoDict["targetType"] = targetType
        self.variableInfoDict["uid"] = uid
        self.variableInfoDict["objectType"] = type(self)
        self.variableInfoDict["name"] = name
        self.variableInfoDict["value"] = value

    # Class Methods
    def get_variable(self):
        return self

    def get_variableInfo(self):
        return self.variableInfoDict

    def get_targetName(self):
        return self.variableInfoDict["targetName"]

    def get_targetType(self):
        return self.variableInfoDict["targetType"]

    def get_uid(self):
        return self.variableInfoDict["uid"]

    def get_objectType(self):
        return self.variableInfoDict["objectType"]

    def get_name(self):
        return self.variableInfoDict["name"]

    def get_value(self):
        return self.variableInfoDict["value"]
