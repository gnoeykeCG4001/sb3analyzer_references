#### Comments regarding module

### Imports
import zipfile
import json
from sb3serializer import sb3serializer
from sb3analyzer import sb3analyzer
from sb3objects import sb3blocks

### Globals
sb3fileName = "CatJumpJump.sb3"

sb3file = zipfile.ZipFile(sb3fileName, 'r')
projectJsonFile = sb3file.read('project.json')
projectJsonString = "".join(projectJsonFile.decode("ascii","ignore")) # protection from using unknown unicode characters

### Create Project Assets
projectJsonObj = json.loads(projectJsonString)

#jsonBreakdown = []

#jsonBreakdown = list(projectJsonObj)

sectionTitleList = list(projectJsonObj)

#print(list(sectionTitleList))

def printIn(val):
    indentLiteral = "\t" * indent
    print(indentLiteral + str(val))
    return indent

indent = 0

for section in sectionTitleList:
    indent = 0
    printIn(section)
    indent += 1
    for xnum in range(len(projectJsonObj[section])):

        #printIn(xnum)
        for subsection in list(projectJsonObj[section][xnum]):
            printIn(subsection)
            try:
                for subsubsection in projectJsonObj[section][xnum][subsection]:
                    printIn("\t" + str(projectJsonObj[section][xnum][subsection][subsubsection]))
            except TypeError:
                printIn("\t" + str(projectJsonObj[section][xnum][subsection]))

    print("\n")

#print(jsonBreakdown)
