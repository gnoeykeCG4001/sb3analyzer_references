# Comments regarding module
#
#

## Imports
from sb3objects import sb3block

## Globals

## Define

## Helper functions

## Class declaration

class SB3Target:       
    def __init__(self, targetJsonObj):
        self.isStage = targetJsonObj['isStage']
        self.type = "stage" if targetJsonObj['isStage'] else "sprite"
        self.name = targetJsonObj['name']
        
        self.targetBlockList = []

        # extract block and add to list
        for blockIdx in targetJsonObj['blocks']:
            self.targetBlockList.append(sb3block.SB3Block(self.name, blockIdx, targetJsonObj['blocks'][blockIdx]))

    # Class Methods
    def get_self(self):
        return self

    def get_isStage(self):
        return self.isStage

    def get_type(self):
        return self.type

    def get_name(self):
        return self.name

    def get_blockList(self):
        return self.targetBlockList
    
    def getBlock_byId(self, idx):
        for tmpBlockObj in self.get_blockList():
            if tmpBlockObj.get_idx() == idx:
                return tmpBlockObj
        return None

    def containsBlock_byId(self, idx):
        for tmpBlockObj in self.get_blockList():
            if tmpBlockObj.get_idx() == idx:
                return True
        return False
    
    def traversalEngin_print(self):
        for indivBlock in self.get_blockList():
            
            print(str(indivBlock.get_opcode()) + "\\" + str(indivBlock.get_idx()) + "\\i" + str(indivBlock.get_blockInputDict()) + "\\f" + str(indivBlock.get_blockFieldDict()))

            '''
            if indivBlock.topLevel == True:
                self.print_blockAndInternals(indivBlock)
                print()
            '''
    
    def print_blockAndInternals(self, currBlock):
        # toplevel, normal
        currBlockOpcode = currBlock.get_opcode()
        currBlockInput = currBlock.get_blockInputDict()
        #currBlockFields = currBlock.get_blockFieldDict()
        #print(currBlockOpcode)
        
        # unpack self
        

        '''
        if currBlockOpcode in ['control_if', 'control_repeat']: #OPCODE_1_BRANCH_LIST:
            pass
        elif currBlockOpcode in ['control_if_else', 'control_repeat_until']: #OPCODE_2_BRANCH_LIST:
            pass
        else:
        '''

    def unpack_block_input(self, inputLabel, input):
        return



    # def traversalEngin_print(self):
    #     for indivBlock in self.get_blockList():
    #         if indivBlock.topLevel == True:
    #             indent = 0
    #             first = 1
    #             self.print_blockAndInternals(indivBlock, indent, first, 0)
    #             print()
    
    # def print_blockAndInternals(self, currBlock, currIndent, first, path):
    #     tabSpace = "\t"*currIndent

    #     currBlockOpcode = currBlock.get_opcode()
    #     currBlockInput = currBlock.get_blockInputDict()
    #     #currBlockFields = currBlock.get_blockFieldDict()
    #     currBlockNextIdx = currBlock.get_next()

    #     #paramsText = ""

    #     # print inside Input
    #     print(tabSpace + str(path) + ": " + str(currBlockOpcode))
        
    #     if first == 1:
    #         currIndent += 1
    #         first = 0

    #     for indivInputKey, indivInputValue in currBlockInput.items():
    #         if (indivInputKey == "SUBSTACK" or indivInputKey == "SUBSTACK2"):
    #             #print(tabSpace + "sub (" + str(indivInputKey) + " : " + str(indivInputValue[1]) + ")")
    #             subBlock = self.getBlock_byId(indivInputValue[1])
    #             path = 1 if indivInputKey == "SUBSTACK" else 2
    #             self.print_blockAndInternals(subBlock, currIndent + 1, first, path)
    #         else:
    #             print(tabSpace + "--> (" + str(indivInputKey) + " : " + str(indivInputValue[1]) + ")")

            

    #     '''
    #     for indivInputKey, indivInputValue in currBlockInput.items():
    #         if (indivInputKey == "SUBSTACK" or indivInputKey == "SUBSTACK2"):
    #             pass
    #         else:
    #             print(tabSpace + "--> (" + str(indivInputKey) + " : " + str(indivInputValue[1]) + ")")
    #     '''
    #     '''
    #     for indivInputKey, indivInputValue in currBlockInput.items():
    #         if (indivInputValue[0] > 0 and indivInputValue[0] < 11):
    #             paramsText += "(" + str(indivInputKey) + " : " + str(indivInputValue[1]) + ")"
    #         else:
    #             currBlockInternalAccess = self.getBlock_byId(indivInputValue[1])
    #             if currBlockInternalAccess != None:
    #                 nextBlock = currBlockInternalAccess
    #                 self.print_blockAndInternals(nextBlock, currIndent+1)

    #     print(tabSpace + str(currBlockOpcode) + paramsText)
    #     paramsText = ""
    #     '''

    #     # print next
    #     if currBlockNextIdx != None:
    #         nextBlock = self.getBlock_byId(currBlockNextIdx)
    #         self.print_blockAndInternals(nextBlock, currIndent, first, 0)
